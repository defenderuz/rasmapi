<?php
include $_SERVER['DOCUMENT_ROOT'] . '/init.php';

if (isset($_POST)) {
    if (!empty($_POST['url'])) {
        $result = getItem($_POST['url']);
        if (count($result)) {
            echo '<b>Описание:</b> ' . $result['description'] . '<br/><br/>';
            echo '<b>Video URL:</b> ' . $result['video_url'] . '<br/><br/>';
            echo '<b>Audio URL:</b> ' . $result['audio_url'];
        }
    }
}
?>
<form method="POST">
    <div>
        <input type="text" name="url" placeholder="https://www.tiktok.com/@l_zolotkovskayaa/video/6769498066778115334"/>
    </div>
    <button>Парсить</button>
</form>