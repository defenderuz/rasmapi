<?php
define('HOME', 'https://musicallydown.com');
define('TOKEN', '325b9025292ccb2533b9');

function curl($url, $postdata='', $cookie='', $proxy='')
{
    $uagent = "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.205 Safari/534.16";
    
    $ch = curl_init( $url );
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);   // возвращает веб-страницу
    curl_setopt($ch, CURLOPT_HEADER, 0);           // возвращает заголовки
    @curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);   // переходит по редиректам
    curl_setopt($ch, CURLOPT_ENCODING, "");        // обрабатывает все кодировки
    curl_setopt($ch, CURLOPT_USERAGENT, $uagent);  // useragent
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);        // таймаут ответа
    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);       // останавливаться после 10-ого редиректа
    if(!empty($postdata))
	{
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
	}
	if(!empty($cookie))
	{
		curl_setopt($ch, CURLOPT_COOKIEJAR, $_SERVER['DOCUMENT_ROOT'].'/cookie.txt');
		curl_setopt($ch, CURLOPT_COOKIEFILE,$_SERVER['DOCUMENT_ROOT'].'/cookie.txt');
	}
	$content = curl_exec( $ch );
	$err     = curl_errno( $ch );
	$errmsg  = curl_error( $ch );
	$header  = curl_getinfo( $ch );
	curl_close( $ch );

	$header['errno']   = $err;
	$header['errmsg']  = $errmsg;
	$header['content'] = $content; 
	return $header;
}

function getItem($url) {
    $return = [];

    /* Главная страница ролика */
    $main_page = curl(HOME . '/download', 'url='.$url.'&vtoken=' . TOKEN, true);
    
    /* Описание */
    preg_match('#<h2(.*?)class="white-text"><b>Video Description</b>: (.*?)</h2>#', $main_page['content'], $description);
    if (isset($description[2])) {
        $return['description'] = trim($description[2]);
    }
    
    /* Получаем ID */
    preg_match('#<input type="hidden" name="q" value="(.*?)">#', $main_page['content'], $main_matches);
    if (isset($main_matches[1])) {
        $item_id = $main_matches[1]; 
    
        /* Видео */
        $posts = 'q=' . $item_id;
        $result = curl(HOME . '/ajax/get_url.json', $posts, true);
        $data = json_decode($result['content'], true);
        if (isset($data['success']) && $data['success'] == 1) {
            $return['video_url'] = $data['url']['d_url'];
        }
    
        /* Аудио */
        $result = curl(HOME . '/mp3/' . $item_id, '', true);
        preg_match('#<source src="(.*?)" type="audio/mpeg">#', $result['content'], $audio_matches);
        if (isset($audio_matches[1])) {
            $return['audio_url'] = $audio_matches[1];
        }
    
    }
    return $return;
}